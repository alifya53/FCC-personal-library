var chai = require('chai');
var assert = chai.assert;

suite('Unit Tests', function(){
  
  //No unit tests needed for this project

});